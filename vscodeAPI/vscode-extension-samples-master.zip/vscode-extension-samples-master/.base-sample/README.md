# Base Sample

This sample is similar to the [helloworld-sample](../helloworld-sample), but it follows the [Sample Guideline](https://github.com/Microsoft/vscode-extension-samples/blob/master/.github/SAMPLE_GUIDELINE.md).

You can easily write a new sample following the guideline by `cp -r .base-sample my-sample`.
