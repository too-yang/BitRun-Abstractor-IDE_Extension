# Document Editing Sample

This sample shows

- How to update document in current active editor through commands.
