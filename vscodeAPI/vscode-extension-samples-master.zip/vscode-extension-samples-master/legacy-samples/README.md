# :warning: Legacy Samples :warning:

These samples are unlikely to receive any updates and might not work with the latest version of VS Code.